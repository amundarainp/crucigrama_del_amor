# Crucigrama del amor 💖 — Deploy rápido
Subí **index.html** + **Juntos.jpeg** juntos a Netlify Drop: https://drop.netlify.com/

## Pasos
1. Poné estos archivos en una carpeta:
   - `index.html` (este)
   - `Juntos.jpeg` (con ese nombre exacto)
2. Entrá a https://drop.netlify.com/ y arrastrá **ambos archivos**.
3. Te devuelve un **link público**. Compartilo por WhatsApp/Telegram.
4. El progreso se guarda en el dispositivo (localStorage). Para reiniciar: **Borrar**.

> Si querés un link estable que puedas actualizar, creá un Netlify Site y subí estos dos archivos.
